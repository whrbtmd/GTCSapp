
/*
   All functions pertaining to geolocation and google maps.
   Note: China has its own Maps configurations and therefore the code
   needs to be modified for Chinese geolocations.
 */

 var trackerId = 0;
 var geocoder;
 var theUser = {};
 var map;
 var socket = io.connect('http://localhost:8000');  //localhost로 연결합니다.
 var markers = [];
 var infowindows = [];
 var limitTime = 30;
 var limitMinute = 1;
 var yellowIcon = 'image/yellowIcon.png';
 var redIcon = 'image/redIcon.png';
  var blueIcon = 'image/blueIcon.png';
 var indexArray1 = [];
 var indexArray2 = [];
 var indexArray3 = [];
 //지도 초기화
 function initialize(){
 var myLatlng = new google.maps.LatLng(35.897354, 128.626733);
  map = new google.maps.Map(document.getElementById('map-canvas'), {

    zoom: 16,

    center: new google.maps.LatLng(35.897563, 128.627349),

    mapTypeId: google.maps.MapTypeId.ROADMAP
  });






  // //클릭했을 때 이벤트
  // google.maps.event.addListener(map, 'click', function(event) {
  // placeMarker(event.latLng);
  // infowindow.setContent("latLng: " + event.latLng); // 인포윈도우 안에 클릭한 곳위 좌표값을 넣는다.
  // infowindow.setPosition(event.latLng);             // 인포윈도우의 위치를 클릭한 곳으로 변경한다.
  // });
  // //클릭 했을때 이벤트 끝
  //  //인포윈도우의 생성
  //  var infowindow = new google.maps.InfoWindow(
  //  { content: '<br><b>원하는 위치을 클릭</b>하면 좌표값생성<br> <b>복사하여 좌료값 입력</b>하십시요',
  //  size: new google.maps.Size(50,50),
  //  position: myLatlng
  //  });
  //  infowindow.open(map);
  //
  //
  // // 마커 생성 합수
  // function placeMarker(location)
  // {
  // var clickedLocation = new google.maps.LatLng(location);
  // var marker = new google.maps.Marker({       position: location,        map: map   });
  // map.setCenter(location);
  // }









  /*google.maps.event.addDomListener(window, 'load', initialize);

  var GmapsCubicBezier = function(lat1, long1, lat2, long2, lat3, long3, lat4, long4, resolution, map) {

    var points = [];

    for (it = 0; it <= 1; it += resolution) {
      points.push(this.getBezier({
        x: lat1,
        y: long1
      }, {
        x: lat2,
        y: long2
      }, {
        x: lat3,
        y: long3
      }, {
        x: lat4,
        y: long4
      }, it));
    }

    for (var i = 0; i < points.length - 1; i++) {
      var Line = new google.maps.Polygon({
        path: [new google.maps.LatLng(points[i].x, points[i].y), new google.maps.LatLng(points[i + 1].x, points[i + 1].y, false)],
          geodesic: true,
          strokeColor: 'black', // 선 색깔
          strokeOpacity: 0.8, //선 투명도
          strokeWeight: 3, // 선 굵기
          fillColor: 'red', // 채워지는 색깔
          fillOpacity: 0.35 // 채워지는 투명도
        //  icons: [{
        //     icon: {
        //         path: 'M 0,-2 0,2',
        //         strokeColor: 'violet',
        //         strokeOpacity: 1,
        //         strokeWeight: 4
        //     },
        //     repeat: '36px'
        // }, {
        //     icon: {
        //         path: 'M -1,-2 -1,2',
        //         strokeColor: 'black',
        //         strokeOpacity: 1,
        //         strokeWeight: 2
        //     },
        //     repeat: '36px'
        // }]
      });
      Line.setMap(map);
    }
    // connect end of line to first point
    var Line = new google.maps.Polygon({
        path: [new google.maps.LatLng(lat1,long1),new google.maps.LatLng(points[points.length-1].x, points[points.length-1].y)],
          geodesic: true,
          strokeColor: 'black', // 선 색깔
          strokeOpacity: 0.8, //선 투명도
          strokeWeight: 3, // 선 굵기
          fillColor: 'red', // 채워지는 색깔
          fillOpacity: 0.35 // 채워지는 투명도
        //  icons: [{
        //     icon: {
        //         path: 'M 0,-2 0,2',
        //         strokeColor: 'violet',
        //         strokeOpacity: 1,
        //         strokeWeight: 4
        //     },
        //     repeat: '36px'
        // }, {
        //     icon: {
        //         path: 'M -1,-2 -1,2',
        //         strokeColor: 'black',
        //         strokeOpacity: 1,
        //         strokeWeight: 2
        //     },
        //     repeat: '36px'
        // }]
      });
      Line.setMap(map);

    return Line;
  };


  GmapsCubicBezier.prototype = {

    B1: function(t) {
      return t * t * t;
    },
    B2: function(t) {
      return 3 * t * t * (1 - t);
    },
    B3: function(t) {
      return 3 * t * (1 - t) * (1 - t);
    },
    B4: function(t) {
      return (1 - t) * (1 - t) * (1 - t);
    },
    getBezier: function(C1, C2, C3, C4, percent) {
      var pos = {};
      pos.x = C1.x * this.B1(percent) + C2.x * this.B2(percent) + C3.x * this.B3(percent) + C4.x * this.B4(percent);
      pos.y = C1.y * this.B1(percent) + C2.y * this.B2(percent) + C3.y * this.B3(percent) + C4.y * this.B4(percent);
      return pos;
    }
  };*/



  function setMarker(data) {
      //eval('var ' + data.id + ';');
      if(data.state == "wait"){
        icon = yellowIcon;
      }else{
        icon = blueIcon;
      }

      var marker = new google.maps.Marker({

          position: new google.maps.LatLng(data.lat, data.lng) ,
          animation: google.maps.Animation.DROP,
          map: map,
          icon: icon,
          title: data.id

      });
      markers.push(marker);

      if(data.holeNum == 1){
      indexArray1.push(data.id);
    }else if(data.holeNum == 2){
      indexArray1.push(data.id);
    }else if(data.holeNum == 3){
      indexArray1.push(data.id);
    }

      attachMessage(marker,data);
      //클릭시 마커위에 텍스트박스(작은것)
      function attachMessage(marker, data) {
        var infowindow = new google.maps.InfoWindow({
          title : data.id,
          content: "캐디이름 : " + data.cname + "<br/>" + "골퍼1 : " + data.gname1
          + "<br/>"+ "골퍼2 : " + data.gname2 + "<br/>" + "골퍼3 : " + data.gname3
          + "<br/>"+ "골퍼4 : " + data.gname4 + "<br/>위치: " + data.loc
          + "<br/>"+ "진행시간 : " + data.h + ":" + data.m + ":" + data.s
        });
        infowindows.push(infowindow);
        marker.addListener('click', function() {
          //function 매개변수에 event를 넣고 setMarker(event.latLng); 를 추가하면 클릭할때마다 마커 추가

          // map.setZoom(18);  //마커클릭시 화면이 커짐
          // map.setCenter(marker.getPosition());
          infowindow.open(marker.get('map'), marker);
        });
  }
} //setMarker 끝

/*
google.maps.event.addListener(map, 'click', function(event) {
placeMarker(event.latLng);
infowindow.setContent("latLng: " + event.latLng); // 인포윈도우 안에 클릭한 곳위 좌표값을 넣는다.
infowindow.setPosition(event.latLng);             // 인포윈도우의 위치를 클릭한 곳으로 변경한다.
});
//클릭 했을때 이벤트 끝
//인포윈도우의 생성
 var infowindow = new google.maps.InfoWindow(
 { content: '<br><b>원하는 위치을 클릭</b>하면 좌표값생성<br> <b>복사하여 좌료값 입력</b>하십시요',
 size: new google.maps.Size(50,50),
 position: myLatlng
 });
 infowindow.open(map);

 // 마커 생성 합수
 function placeMarker(location)
 {
 var clickedLocation = new google.maps.LatLng(location);
 var marker = new google.maps.Marker({       position: location,        map: map   });

 }

    화면 상단에 텍스트박스 띄우기
  var widgetDiv = document.getElementById('save-widget');
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(widgetDiv);

    // Append a Save Control to the existing save-widget div.
    var saveWidget = new google.maps.SaveWidget(widgetDiv);

  $.ajax({
    url: 'http://localhost:80/gpstest/php/coursePos.php',
    data:{

    },
    dataType: 'jsonp',
    success: function(data){
      console.log(data);
      if(data.result == "success"){

      }
      else{
        window.alert('오류가 발생하였습니다.');
      }

    },
    error:function(){

      window.alert('요류가 발생하였습니다.');
    }
  });*/

    // var triangleCoords = [
    //     {lat: 35.897354, lng: 128.626733}, //아래 lat값
    //     {lat: 35.897880, lng: 128.626365},
    //     {lat: 35.898402, lng: 128.626025}, // 왼쪽 lng값
    //     {lat: 35.899258, lng: 128.626159},
    //     {lat: 35.899416, lng: 128.626382},// 위 lat값
    //     {lat: 35.899236, lng: 128.626545},
    //     {lat: 35.898715, lng: 128.626443},
    //     {lat: 35.897541, lng: 128.627017} //오른 lng값
    //   ];
      /*var curvedLine = new GmapsCubicBezier(
        35.897354, 128.626733,
        35.897880, 128.626365,
        35.898253, 128.625765,
        35.899258, 128.626159,
        0.01, map);
      var curvedLine = new GmapsCubicBezier(
        35.899258, 128.626159,
        35.899416, 128.626382,
        35.899236, 128.626545,
        35.898715, 128.626443,
        0.01, map);
      var curvedLine = new GmapsCubicBezier(
        35.898715, 128.626443,
        35.898045, 128.626719,
        35.897563, 128.627349,
        35.897354, 128.626733,
        0.01, map);*/
    // var c1toplat = 35.89941679091893;
    // var c1botlat = 35.89735485563055;
    // var c1leftlng = 128.62602531909943;
    // var c1rightlng = 128.62701773643494;
    // var triangleCoords1 = [
    //    {lat:35.900222, lng:128.625944},//아래 lat값
    //    {lat:35.900448, lng:128.625518},
    //    {lat:35.900742, lng:128.625236}, // 왼쪽 lng값
    //    {lat:35.901402, lng:128.625293},
    //    {lat:35.902002, lng:128.625344},
    //    {lat:35.902382, lng:128.625668}, // 위 lat값
    //    {lat:35.902380, lng:128.625893},
    //    {lat:35.901993, lng:128.626119},
    //    {lat:35.901693, lng:128.626178},// 오른 lng값
    //    {lat:35.901052, lng:128.625875},
    //    {lat:35.900859, lng:128.625872},
    //    {lat:35.900516, lng:128.625907}
    //   ];
    /*  35.900859, 128.625872,
      35.900516, 128.625907,
      35.900222, 128.625944,
       35.900448, 128.625518,
      35.900742, 128.625236,
       35.901402, 128.625293,
       35.902002, 128.625344,
       35.902382, 128.625668,
       35.902380, 128.625893,
       35.901993, 128.626119,
       35.901693, 128.626178,
       35.901052, 128.625875,


       var curvedLine = new GmapsCubicBezier(
         35.900859, 128.625872,
         35.900516, 128.625907,
         35.900222, 128.625944,
          35.900448, 128.625518,
         0.01, map);
       var curvedLine = new GmapsCubicBezier(
         35.900448, 128.625518,
        35.900742, 128.625236,
         35.901402, 128.625293,
         35.902002, 128.625344,
         0.01, map);
       var curvedLine = new GmapsCubicBezier(
         35.902002, 128.625344,
         35.902382, 128.625668,
         35.902380, 128.625893,
         35.901993, 128.626119,
         0.01, map);
         var curvedLine = new GmapsCubicBezier(
           35.901993, 128.626119,
           35.901693, 128.626178,
           35.901052, 128.625875,
            35.900859, 128.625872,
           0.01, map);*/
    // var c2toplat = 35.90238249406084;
    // var c2botlat = 35.90022286482123;
    // var c2leftlng = 128.62523674964905;
    // var c2rightlng = 128.62617820501328;
    // var triangleCoords2 = [
    //   {lat: 35.902734, lng: 128.625655},//아래 lat값
    //   {lat: 35.903251, lng: 128.625333},
    //   {lat: 35.903655, lng: 128.625215}, // 왼쪽 lng값
    //   {lat: 35.904476, lng: 128.625386},
    //   {lat: 35.904720, lng: 128.625887},
    //   {lat: 35.904659, lng: 128.626004}, // 위 lat값
    //   {lat: 35.904372, lng: 128.626009},
    //   {lat: 35.903985, lng: 128.626019},
    //   {lat: 35.903790, lng: 128.625936},
    //   {lat: 35.903642, lng: 128.625960},
    //   {lat: 35.903551, lng: 128.626239},
    //   {lat: 35.903425, lng: 128.626287},// 오른 lng값
    //   {lat: 35.903199, lng: 128.626196},
    //   {lat: 35.902847, lng: 128.625848}
    //     ];
/*  35.903199,   128.626196,
  35.903084, 128.626040,
  35.902747,   128.625848,
  35.902734,  128.625655,
  35.903251,  128.625333,
  35.903655,   128.625215,
  35.904476,   128.625386,
  35.904720,   128.625687,
  35.904859,   128.626164,
  35.904372,   128.626009,
  35.903985,   128.626119,
  35.903790,   128.625936,
  35.903642,   128.625960,
  35.903551,   128.626339,
  35.903425,   128.626387,

var test = new GmapsCubicBezier(
  35.899095, 128.622796,
  35.899312, 128.623858,
  35.898626, 128.624083,
  35.899095, 128.622796,
  0.01, map);
        var curvedLine = new GmapsCubicBezier(
          35.903199,   128.626196,
          35.903084, 128.626040,
          35.902747,   128.625848,
          35.902734,  128.625655,
          0.01, map);
        var curvedLine = new GmapsCubicBezier(
          35.902734,  128.625655,
          35.903251,  128.625333,
          35.903655,   128.625215,
          35.904476,   128.625386,
          0.01, map);
        var curvedLine = new GmapsCubicBezier(
          35.904476,   128.625386,
          35.904720,   128.625687,
          35.904859,   128.626164,
          35.904372,   128.626009,
          0.01, map);
        var curvedLine = new GmapsCubicBezier(
          35.904372,   128.626009,
          35.903985,   128.626119,
          35.903790,   128.625936,
          35.903642,   128.625960,
          0.01, map);
        var curvedLine = new GmapsCubicBezier(
          35.903642,   128.625960,
          35.903551,   128.626339,
          35.903425,   128.626387,
          35.903199,   128.626196,
          0.01, map);*/

    // var c3toplat = 35.90485925987619;
    // var c3botlat = 35.902734460243614;
    // var c3leftlng = 128.62521529197693;
    // var c3rightlng = 128.62638741731644;
    //
    // var triangleCoords3 = [
    //   {lat: 35.905350, lng: 128.626223},// 왼쪽 lng값
    //   {lat: 35.905843, lng: 128.626383},
    //   {lat: 35.906304, lng: 128.626593},
    //   {lat: 35.906679, lng: 128.626797},
    //   {lat: 35.906960, lng: 128.627264},
    //   {lat: 35.906901, lng: 128.627363},// 위 lat값 // 오른 lng값
    //   {lat: 35.906123, lng: 128.627170},
    //   {lat: 35.905417, lng: 128.626902},//아래 lat값
    //   {lat: 35.905154, lng: 128.626572}
    //
    //       ];
    //
    //       var triangleCoords3 = [
    //         {lat: 35.905350, lng: 128.626223},// 왼쪽 lng값
    //         {lat: 35.905843, lng: 128.626253},
    //         {lat: 35.906304, lng: 128.626593},
    //         {lat: 35.906679, lng: 128.626797},
    //         {lat: 35.907086, lng: 128.627285},
    //         {lat: 35.907107, lng: 128.627605},// 위 lat값 // 오른 lng값
    //         {lat: 35.906123, lng: 128.627170},
    //         {lat: 35.905226, lng: 128.626956}//아래 lat값
    //
    //             ];

           /*35.906123,  128.627170,
           35.905226,  128.626956,
           35.904900,  128.626654,
           35.905350,  128.626223,
           35.905843,  128.626253,
           35.906304,  128.626593,
           35.906679,  128.626797,
           35.907086,  128.627285,
           35.907107,  128.627605,


          var curvedLine = new GmapsCubicBezier(
            35.906123,  128.627170,
            35.905226,  128.626956,
            35.904900,  128.626654,
            35.905350,  128.626223,
            0.01, map);
          var curvedLine = new GmapsCubicBezier(
            35.905350,  128.626223,
            35.905843,  128.626253,
            35.906304,  128.626593,
            35.906679,  128.626797,
            0.01, map);
          var curvedLine = new GmapsCubicBezier(
            35.906679,  128.626797,
            35.907086,  128.627285,
            35.907107,  128.627605,
            35.906123,  128.627170,
            0.01, map);*/

    // var c4toplat = 35.90710783539123;
    // var c4botlat = 35.90522642294811;
    // var c4leftlng = 128.62622380256653;
    // var c4rightlng = 128.6276051402092;



          /*var curvedLine = new GmapsCubicBezier(
            35.906679,  128.626797,
            35.907086,  128.627285,
            35.907107,  128.627605,
            35.906123,  128.627170,
            0.01, map);*/

    //   var college1 = [
    //     {lat: 35.895993, lng: 128.620209},
    //     {lat: 35.896295, lng: 128.620110},// 왼쪽 lng값
    //     {lat: 35.896591, lng: 128.621110},// top,right
    //     {lat: 35.895928, lng: 128.620988} // bottom
    //         ];
    //
    // var college1BotLat = 35.895928;
    // var college1TopLat = 35.896591;
    // var college1LeftLng = 128.620110;
    // var college1RightLng = 128.621110;
    //
    // var college11 = [
    //   {lat: 35.895993, lng: 128.620209},//왼쪽아래
    //   {lat: 35.896295, lng: 128.620110},//왼쪽위
    //   {lat: 35.896351, lng: 128.620330},//오른쪽위
    //   {lat: 35.895968, lng: 128.620438} //오른쪽아래
    //       ];
    // var college11BotLat = 35.895968;
    // var college11TopLat = 35.896351;
    // var college11LeftLng = 128.620110;
    // var college11RightLng = 128.620438;
    //
    //
    // var college12 = [
    //   {lat: 35.895973, lng: 128.620430},//왼쪽아래
    //   {lat: 35.896355, lng: 128.620325},//왼쪽위
    //   {lat: 35.896460, lng: 128.620650},//오른쪽위
    //   {lat: 35.895938, lng: 128.620728}//오른쪽아래
    //       ];
    // var college12BotLat = 35.895938;
    // var college12TopLat = 35.896460;
    // var college12LeftLng = 128.620325;
    // var college12RightLng = 128.620728;
    //
    //
    // var college13 = [
    //   {lat: 35.895938, lng: 128.620728},//왼쪽아래
    //   {lat: 35.896460, lng: 128.620650},//왼쪽위
    //   {lat: 35.896591, lng: 128.621110},//오른쪽위
    //   {lat: 35.895928, lng: 128.620988} //오른쪽아래
    //       ];
    // var college13BotLat = 35.895928;
    // var college13TopLat = 35.896591;
    // var college13LeftLng = 128.620650;
    // var college13RightLng = 128.621110;
    //
    //
    //
    // var college2 = [
    //   {lat: 35.896015, lng: 128.621049},// 왼쪽 lng값
    //   {lat: 35.896537, lng: 128.621215},
    //   {lat: 35.896217, lng: 128.622408},
    //   {lat: 35.895692, lng: 128.622108}
    //       ];
    //
    // var college2BotLat = 35.895692;
    // var college2TopLat = 35.896537;
    // var college2LeftLng = 128.621049;
    // var college2RightLng = 128.622408;
    //
    //
    //
    // var college21 = [
    //   {lat: 35.896015, lng: 128.621049},//왼쪽아래
    //   {lat: 35.896537, lng: 128.621215},//왼쪽위
    //   {lat: 35.896445, lng: 128.621608},//오른쪽위
    //   {lat: 35.895902, lng: 128.621408}//오른쪽아래
    //       ];
    // var college21BotLat = 35.895902;
    // var college21TopLat = 35.896537;
    // var college21LeftLng = 128.621049;
    // var college21RightLng = 128.621608;
    //
    //
    // var college22 = [
    //   {lat: 35.895902, lng: 128.621408},//왼쪽아래
    //   {lat: 35.896445, lng: 128.621608},//왼쪽위
    //   {lat: 35.896327, lng: 128.621978},//오른쪽위
    //   {lat: 35.895792, lng: 128.621778}//오른쪽아래
    //       ];
    // var college22BotLat = 35.895792;
    // var college22TopLat = 35.896445;
    // var college22LeftLng = 128.621408;
    // var college22RightLng = 128.621978;
    //
    //
    // var college23 = [
    //   {lat: 35.895792, lng: 128.621778},//왼쪽아래
    //   {lat: 35.896327, lng: 128.621978},//왼쪽위
    //   {lat: 35.896217, lng: 128.622408},//오른쪽위
    //   {lat: 35.895692, lng: 128.622108}//오른쪽아래
    //       ];
    // var college23BotLat = 35.895692;
    // var college23TopLat = 35.896327;
    // var college23LeftLng = 128.621778;
    // var college23RightLng = 128.622408;
    //
    //
    //
    // var college3 = [
    //   {lat: 35.895450, lng: 128.622178},//왼쪽아래
    //   {lat: 35.896146, lng: 128.622489},//왼쪽위
    //   {lat: 35.895403, lng: 128.623771},//오른쪽위
    //   {lat: 35.894788, lng: 128.623250} //오른쪽아래
    //       ];
    //
    // var college3BotLat = 35.894788;
    // var college3TopLat = 35.896146;
    // var college3LeftLng = 128.622178;
    // var college3RightLng = 128.623771;
    //
    // var college31 = [
    //   {lat: 35.895450, lng: 128.622178},//왼쪽아래
    //   {lat: 35.896146, lng: 128.622489},//왼쪽위
    //   {lat: 35.895903, lng: 128.622891},//오른쪽위
    //   {lat: 35.895188, lng: 128.622600} //오른쪽아래
    //       ];
    // var college31BotLat = 35.895188;
    // var college31TopLat = 35.896146;
    // var college31LeftLng = 128.622178;
    // var college31RightLng = 128.622891;
    //
    //
    // var college32 = [
    //   {lat: 35.895188, lng: 128.622600},//왼쪽아래
    //   {lat: 35.895903, lng: 128.622891},//왼쪽위
    //   {lat: 35.895703, lng: 128.623241},//오른쪽위
    //   {lat: 35.894988, lng: 128.622950} //오른쪽아래
    //       ];
    // var college32BotLat = 35.894988;
    // var college32TopLat = 35.895903;
    // var college32LeftLng = 128.622600;
    // var college32RightLng = 128.623241;
    //
    //
    // var college33 = [
    //   {lat: 35.894988, lng: 128.622950},//왼쪽아래
    //   {lat: 35.895703, lng: 128.623241},//왼쪽위
    //   {lat: 35.895403, lng: 128.623771},//오른쪽위
    //   {lat: 35.894788, lng: 128.623250} //오른쪽아래
    //       ];
    // var college33BotLat = 35.894788;
    // var college33TopLat = 35.895703;
    // var college33LeftLng = 128.622950;
    // var college33RightLng = 128.623771;

    var college1 = [
      {lat: 35.895439, lng: 128.620996}, // b,l
      {lat: 35.896414, lng: 128.620996}, // t,l
      {lat: 35.896414, lng: 128.621312}, // t,r
      {lat: 35.895439, lng: 128.621312} // b,r
          ];
    var college2 = [
      {lat: 35.895439, lng: 128.621312},
      {lat: 35.896414, lng: 128.621312},// 왼쪽 lng값
      {lat: 35.896414, lng: 128.621622},// top,right
      {lat: 35.895439, lng: 128.621622} // bottom
          ];
    var college3 = [
      {lat: 35.895439, lng: 128.621622},
      {lat: 35.896414, lng: 128.621622},// 왼쪽 lng값
      {lat: 35.896414, lng: 128.622021},// top,right
      {lat: 35.895439, lng: 128.622021} // bottom
          ];
          // 학교 좌표
           var toplat = 35.896712798428645;
           var botlat = 35.89651724697725;
           var leftlng = 128.62010300159454;
           var rightlng = 128.6203283071518;

           //1홀에 대한 좌표
            var c1toplat = 35.896414;
            var c1botlat = 35.895439;
            var c1leftlng = 128.620996;
            var c1rightlng = 128.621312;

           //2홀에 대한 좌표
            var c2toplat = 35.896414;
            var c2botlat = 35.895439;
            var c2leftlng = 128.621312;
            var c2rightlng = 128.621622;

           //3홀에 대한 좌표
            var c3toplat = 35.896414;
            var c3botlat = 35.895439;
            var c3leftlng = 128.621622;
            var c3rightlng = 128.622021;
//{lat: 35.897463, lng: 128.626874}
    // var bermudaTriangle = new google.maps.Polygon({
    //   paths: triangleCoords,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var bermudaTriangle1 = new google.maps.Polygon({
    //   paths: triangleCoords1,
    //   geodesic: true,
    //   strokeColor: 'yellow',
    //   strokeOpacity: 0.8,
    //   strokeWeight: 3,
    //   fillColor: 'yellow',
    //   fillOpacity: 0.35
    // });
    // var bermudaTriangle2 = new google.maps.Polygon({
    //   paths: triangleCoords2,
    //   geodesic: true,
    //   strokeColor: 'blue',
    //   strokeOpacity: 0.8,
    //   strokeWeight: 3,
    //   fillColor: 'blue',
    //   fillOpacity: 0.35
    // });
    // var bermudaTriangle3 = new google.maps.Polygon({
    //   paths: triangleCoords3,
    //   geodesic: true,
    //   strokeColor: '#05C664',
    //   strokeOpacity: 0.8,
    //   strokeWeight: 3,
    //   fillColor: '#05C664',
    //   fillOpacity: 0.35
    // });
    var college1 = new google.maps.Polygon({
      paths: college1,
      geodesic: true,
      strokeColor: '#05C664',
      strokeOpacity: 0.8,
      strokeWeight: 3,
      fillColor: '#05C664',
      fillOpacity: 0.35
    });
    var college2 = new google.maps.Polygon({
      paths: college2,
      geodesic: true,
      strokeColor: '#05C664',
      strokeOpacity: 0.8,
      strokeWeight: 3,
      fillColor: '#05C664',
      fillOpacity: 0.35
    });
    var college3 = new google.maps.Polygon({
      paths: college3,
      geodesic: true,
      strokeColor: '#05C664',
      strokeOpacity: 0.8,
      strokeWeight: 3,
      fillColor: '#05C664',
      fillOpacity: 0.35
    });
    // var college11 = new google.maps.Polygon({
    //   paths: college11,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college12 = new google.maps.Polygon({
    //   paths: college12,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college13 = new google.maps.Polygon({
    //   paths: college13,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college21 = new google.maps.Polygon({
    //   paths: college21,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college22 = new google.maps.Polygon({
    //   paths: college22,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college23 = new google.maps.Polygon({
    //   paths: college23,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college31 = new google.maps.Polygon({
    //   paths: college31,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college32 = new google.maps.Polygon({
    //   paths: college32,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // var college33 = new google.maps.Polygon({
    //   paths: college33,
    //   geodesic: true,
    //   strokeColor: 'red', // 선 색깔
    //   strokeOpacity: 0.8, //선 투명도
    //   strokeWeight: 3, // 선 굵기
    //   fillColor: 'red', // 채워지는 색깔
    //   fillOpacity: 0.35 // 채워지는 투명도
    // });
    // bermudaTriangle.setMap(map);
    // bermudaTriangle1.setMap(map);
    // bermudaTriangle2.setMap(map);
    // bermudaTriangle3.setMap(map);
    college1.setMap(map);
    college2.setMap(map);
    college3.setMap(map);
    // college11.setMap(map);
    // college12.setMap(map);
    // college13.setMap(map);
    // college21.setMap(map);
    // college22.setMap(map);
    // college23.setMap(map);
    // college31.setMap(map);
    // college32.setMap(map);
    // college33.setMap(map);
    // var marker = new google.maps.Marker({
    //     position: myLatLng,
    //     map: map,
    //     title: 'Hello World!'
    //   });

 // 학교 좌표
  var toplat = 35.896712798428645;
  var botlat = 35.89651724697725;
  var leftlng = 128.62010300159454;
  var rightlng = 128.6203283071518;

  socket.on('gps', function (data) { // node서버에서 받아옴
    //마커에대한 정보와 텍스트창의 정보를 변경하기 위함
    //마커의 배열에 1개 이상 들어있다면 아래 코드 실행
    if(markers.length > 0){
      //마커 배열에 data에서 받은 캐디 아이디와 동일한 마커가 있는지 체크
      var exi = false;
      //배열에 같은 케디 아이디가 있다면 인덱스 값을 얻기위한 변수
      var arrayNum;

        /*소켓에서 받은 정보와 이미 마커배열에 저장된 타이틀을 비교하기위함
        만약 마커 배열에 소켓에서 받은 타이틀이 없다면 새로 마커를 찍음*/
        for(var i=0; i < markers.length; i++ ){

          //
          if(data.id == markers[i].title){
            exi = true;
            arrayNum = i;
          }



        }
        if(exi){ //배열안에 같은 캐디의 이름인 마커가 있다면
          // 마커 위치 업데이트
          markers[arrayNum].setPosition( new google.maps.LatLng(data.lat,data.lng));
          var text = "캐디이름 : " + data.cname + "<br/>" + "골퍼1 : " + data.gname1
          + "<br/>"+ "골퍼2 : " + data.gname2 + "<br/>" + "골퍼3 : " + data.gname3
          + "<br/>"+ "골퍼4 : " + data.gname4 + "<br/>위치: " + data.loc
          + "<br/>"+ "진행시간 : " + data.h + ":" + data.m + ":" + data.s;
          //마커 텍스트창 업데이트
          infowindows[arrayNum].setContent(text);
          if(data.state == "wait"){ //대기 상태 체크
            markers[arrayNum].setIcon(yellowIcon); // 대기일경우 노란마커로 변경
          }else if(data.iconColor == "red"){

              markers[arrayNum].setIcon(redIcon);
              markers[arrayNum].setAnimation(google.maps.Animation.BOUNCE);

          }else if(data.iconColor == "blue"){
            markers[arrayNum].setIcon(blueIcon);
            markers[arrayNum].setAnimation(null);
          }
        }else{// 배열에 없는경우 마커를 새로 생성 if(exi) 끝
          setMarker(data);
        }

    }else{
      setMarker(data);
    }

    console.log(data);
  });

  socket.on('delete', function (deleteId) {

    for(var i=0; i < markers.length; i++ ){

      if(deleteId == markers[i].title){
        markers[i].setMap(null);
        //markers[i] = null;
      }

    }

      if(deleteId == indexArray1[0]){
        for(var i =0 ; i < indexArray1.length-1;i++)
        indexArray1[i] = indexArray1[i+1];
      }else if(deleteId == indexArray2[0]){
        for(var i =0 ; i < indexArray2.length-1;i++)
        indexArray2[i] = indexArray2[i+1];
      }else if(deleteId == indexArray3[0]){
        for(var i =0 ; i < indexArray3.length-1;i++)
        indexArray3[i] = indexArray3[i+1];
      }

  });
}; //init 종료



//Load our maps/geolocation functions
function loadAPI() {
  var script = document.createElement("script");
  script.type = "text/javascript";

  //With API Key
  script.src = "https://maps.googleapis.com/maps/api/js?v=3.20&key=AIzaSyDv1IGjg0gCic6Pc974cxQhGNt7PNSgA6I&libraries=places,geometry&callback=initialize";
  document.body.appendChild(script);
}
//Run this file after the document/window is loaded to avoid errors
window.onload = loadAPI;
